import React, { useState, useEffect } from "react";
import { Outlet, Link, useNavigate, useLocation } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import {
  Zap,
  ShoppingCart,
  Heart,
  User,
  Sun,
  Moon,
  Menu,
  X,
  Search,
  LogOut,
  ArrowRight,
  ClipboardList,
  Package,
  MapPin,
} from "lucide-react";
import clsx from "clsx";
import { useTheme } from "@/shared/hooks/useAuth";
import { customerLogout } from "@/storefront/store/customerSlice";

import StoreHeader from "@/storefront/components/StoreHeader";

export default function StorefrontLayout() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const location = useLocation();

  const { customer, token } = useSelector((s) => s.customer);
  const cartItems = useSelector((s) => s.cart.items);
  const wishlistItems = useSelector((s) => s.wishlist.items);

  const { isDark, toggle: toggleTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [scrolled, setScrolled] = useState(false);
  const [showSubProducts, setShowSubProducts] = useState(false);

  useEffect(() => {
    const closeMenu = () => setShowSubProducts(false);

    if (showSubProducts) {
      document.addEventListener("click", closeMenu);
    }

    return () => {
      document.removeEventListener("click", closeMenu);
    };
  }, [showSubProducts]);
  // Track page scroll to toggle header background glassmorphism
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const wishlistCount = wishlistItems.length;

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleLogout = () => {
    dispatch(customerLogout());
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-app flex flex-col transition-colors duration-300">
      {/* Top Promotional Banner */}
      {/* <div className="bg-gradient-to-r from-brand-600 to-indigo-600 text-white text-xs py-2 px-4 text-center font-medium tracking-wide">
        ⚡ FREE SHIPPING ON ORDERS OVER ₹999 & COMPLIMENTARY TRIAL GIFTS IN EVERY ORDER!
      </div> */}

      {/* Main Glassmorphic Header */}
      <StoreHeader
        scrolled={scrolled}
        location={location}
        showSubProducts={showSubProducts}
        setShowSubProducts={setShowSubProducts}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        handleSearchSubmit={handleSearchSubmit}
        toggleTheme={toggleTheme}
        isDark={isDark}
        wishlistCount={wishlistCount}
        cartCount={cartCount}
        token={token}
        customer={customer}
        handleLogout={handleLogout}
        setMobileMenuOpen={setMobileMenuOpen}
      />

      {/* Mobile Sidebar Navigation Drawer */}
      <div
        className={clsx(
          "fixed inset-0 z-50 transition-opacity duration-300 md:hidden",
          mobileMenuOpen
            ? "opacity-100 pointer-events-auto"
            : "opacity-0 pointer-events-none",
        )}
      >
        {/* Backdrop overlay */}
        <div
          className="absolute inset-0 bg-black/40 backdrop-blur-xs"
          onClick={() => setMobileMenuOpen(false)}
        />

        {/* Drawer container */}
        <div
          className={clsx(
            "absolute right-0 top-0 bottom-0 w-[270px] bg-app border-l border-app shadow-2xl flex flex-col p-5 transition-transform duration-300 ease-out z-10",
            mobileMenuOpen ? "translate-x-0" : "translate-x-full",
          )}
        >
          <div className="flex items-center justify-between mb-8">
            <span className="font-display font-bold text-base text-app">
              Menu
            </span>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="p-1.5 rounded-xl border border-app hover:bg-surface text-muted hover:text-app"
            >
              <X size={18} />
            </button>
          </div>

          {/* Search bar inside drawer */}
          <form onSubmit={handleSearchSubmit} className="relative mb-6">
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-surface border border-app rounded-xl py-2 pl-4 pr-10 text-xs text-app focus:outline-none placeholder:text-muted"
            />
            <button
              type="submit"
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-app"
            >
              <Search size={14} />
            </button>
          </form>

          {/* Nav items list */}
          <nav className="flex flex-col gap-4 font-medium text-sm">
            <Link
              to="/"
              className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-surface text-app/80 hover:text-brand-500"
            >
              <Package size={16} /> Home
            </Link>
            <Link
              to="/products"
              className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-surface text-app/80 hover:text-brand-500"
            >
              <ShoppingCart size={16} /> Shop Catalog
            </Link>
            <Link
              to="/tracking"
              className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-surface text-app/80 hover:text-brand-500"
            >
              <MapPin size={16} /> Track Order
            </Link>
            {token && customer && (
              <>
                <Link
                  to="/profile"
                  className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-surface text-app/80 hover:text-brand-500"
                >
                  <User size={16} /> My Account
                </Link>
                <Link
                  to="/profile/orders"
                  className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-surface text-app/80 hover:text-brand-500"
                >
                  <ClipboardList size={16} /> My Orders
                </Link>
              </>
            )}
          </nav>

          {/* Logout or login button in drawer footer */}
          <div className="mt-auto pt-6 border-t border-app">
            {token && customer ? (
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 w-full justify-center py-2 px-4 border border-red-500/30 text-red-500 rounded-xl text-xs hover:bg-red-500/5 transition-all"
              >
                <LogOut size={14} /> Log Out
              </button>
            ) : (
              <Link
                to="/auth/login"
                className="flex items-center gap-2 w-full justify-center btn-primary py-2 rounded-xl text-xs"
              >
                <User size={14} /> Sign In
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Main Page Layout Wrapper */}
      <main className="flex-1 w-full relative">
        <Outlet />
      </main>

      {/* Modern High-End Footer */}
      <footer className="bg-surface border-t border-app py-16 transition-colors duration-300">
        <div className="mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Logo & Description */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2.5 group">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-indigo-600 text-white">
                <Zap size={14} strokeWidth={2.5} />
              </div>
              <span className="font-display font-bold text-base text-app">
                Aura<span className="text-brand-500">Store</span>
              </span>
            </Link>
            <p className="text-xs text-muted leading-relaxed">
              Curating premium, hand-crafted designer streetwear,
              high-performance athletic apparel, and timeless accessories.
            </p>
          </div>

          {/* Quick links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-app">
              Shop Catalog
            </h4>
            <div className="flex flex-col gap-2 text-xs">
              <Link to="/products" className="text-muted hover:text-app">
                All Products
              </Link>
              <Link
                to="/products?collection=Summer"
                className="text-muted hover:text-app"
              >
                Summer Collection
              </Link>
              <Link
                to="/products?collection=Activewear"
                className="text-muted hover:text-app"
              >
                Activewear
              </Link>
              <Link
                to="/products?collection=Essentials"
                className="text-muted hover:text-app"
              >
                Daily Essentials
              </Link>
            </div>
          </div>

          {/* Customer Support */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-app">
              Customer Services
            </h4>
            <div className="flex flex-col gap-2 text-xs">
              <Link to="/tracking" className="text-muted hover:text-app">
                Track Your Order
              </Link>
              <Link to="/profile/orders" className="text-muted hover:text-app">
                Return & Exchanges
              </Link>
              <a
                href="mailto:support@aurastore.com"
                className="text-muted hover:text-app"
              >
                Contact Support
              </a>
              <span className="text-muted">Phone: +91 44 2817 9000</span>
            </div>
          </div>

          {/* Newsletter signup */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-app">
              Join Aura List
            </h4>
            <p className="text-xs text-muted leading-relaxed">
              Subscribe to get notifications about drops, exclusive discounts,
              and active campaigns.
            </p>
            <div className="flex items-center gap-1.5 pt-1">
              <input
                type="email"
                placeholder="your.email@gmail.com"
                className="bg-app border border-app text-xs px-3 py-2 rounded-xl focus:outline-none w-full placeholder:text-muted"
              />
              <button className="bg-brand-500 hover:bg-brand-600 p-2 text-white rounded-xl transition-all">
                <ArrowRight size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Footer bottom bar */}
        <div className="mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-app flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] text-muted">
          <p>
            © {new Date().getFullYear()} AuraStore Inc. All rights reserved.
            Made for premium commerce.
          </p>
          <div className="flex items-center gap-6">
            <Link to="/support/privacy" className="hover:text-app">
              Privacy Policy
            </Link>
            <Link to="/support/terms" className="hover:text-app">
              Terms of Use
            </Link>
            <Link
              to="/admin"
              className="text-brand-500 font-semibold hover:text-brand-600"
            >
              Admin Dashboard
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
