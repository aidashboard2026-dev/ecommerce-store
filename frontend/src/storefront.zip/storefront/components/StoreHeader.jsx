import React from "react";
import { Link } from "react-router-dom";
import clsx from "clsx";
import {
  Zap,
  ShoppingCart,
  Heart,
  User,
  Sun,
  Moon,
  Search,
  Menu,
  LogOut,
  ClipboardList,
} from "lucide-react";

export default function StoreHeader({
  scrolled,
  location,
  showSubProducts,
  setShowSubProducts,
  searchQuery,
  setSearchQuery,
  handleSearchSubmit,
  toggleTheme,
  isDark,
  wishlistCount,
  cartCount,
  token,
  customer,
  handleLogout,
  setMobileMenuOpen,
}) {
  return (
    <>
      {/* Paste your existing <header>...</header> code here */}

      <header className={clsx(
        "sticky top-0 z-40 transition-all duration-300 border-b",
        scrolled
          ? "bg-app/80 backdrop-blur-lg border-app py-3 shadow-sm"
          : "bg-transparent border-transparent py-5"
      )}>
        <div className="mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
          
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group shrink-0">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-indigo-600 text-white shadow-glow-sm transition-transform duration-300 group-hover:scale-105">
              <Zap size={18} strokeWidth={2.5} />
            </div>
            <span className="font-display font-bold text-lg text-app tracking-tight">
              Aura<span className="text-brand-500">Store</span>
            </span>
          </Link>

          {/* Navigation Links - Desktop */}
          <nav className="hidden md:flex items-center gap-8 font-medium text-sm">
            <Link to="/" className={clsx(
              "transition-colors duration-200 hover:text-brand-500",
              location.pathname === '/' ? "text-brand-500 font-semibold" : "text-app/80"
            )}>
              Home
            </Link>
            <Link to="/products" className={clsx(
              "transition-colors duration-200 hover:text-brand-500",
              location.pathname === '/products' ? "text-brand-500 font-semibold" : "text-app/80"
            )}>
              Shop Catalog
            </Link>
            <div>
            <Link
              to="/sub-products"
              className={clsx(
                "transition-colors duration-200 hover:text-brand-500",
                location.pathname === "/sub-products"
                  ? "text-brand-500 font-semibold"
                  : "text-app/80"
              )}
            >
              Sub Products
            </Link>

              {showSubProducts && (
                <div
                  className="
                    absolute
                    top-full
                    left-[-370px]
                    mt-3
                    grid
                    grid-cols-5
                    gap-10
                    w-[1250px]
                    bg-white
                    rounded-2xl
                    shadow-xl
                    p-8
                    z-50
                  "
                >

                {/* T-Shirts */}
                <div>
                  <h3 className="font-bold mb-3 text-brand-500">
                    T-Shirts
                  </h3>

                  <Link
                    to="/category/round-neck"
                    onClick={() => setShowSubProducts(false)}
                    className="block mb-2 hover:text-brand-500"
                  >
                    Round neck T- shirt 
                  </Link>

                  <Link to="/category/v-neck" className="block mb-2 hover:text-brand-500">
                    V-Neck T-Shirt
                  </Link>

                  <Link to="/category/polo" className="block mb-2 hover:text-brand-500">
                    Polo T-Shirt
                  </Link>

                  <Link to="/category/henley" className="block mb-2 hover:text-brand-500">
                    Henley T-Shirt
                  </Link>

                  <Link to="/category/oversized" className="block mb-2 hover:text-brand-500">
                    Oversized T-Shirt
                  </Link>

                  <Link to="/category/graphic" className="block mb-2 hover:text-brand-500">
                    Graphic Printed T-Shirt
                  </Link>

                  <Link to="/category/plain" className="block mb-2 hover:text-brand-500">
                    Plain T-Shirt
                  </Link>

                  <Link to="/category/back-print" className="block py-1 hover:text-brand-500 transition-colors">
                    Back Print T-Shirt
                  </Link>

                  <Link to="/category/color-tshirt" className="block py-1 hover:text-brand-500 transition-colors">
                    Color T-Shirt
                  </Link>

                  <Link to="/category/embroidery-tshirt" className="block py-1 hover:text-brand-500 transition-colors">
                    Embroidery Design T-Shirt
                  </Link>
                </div>

                {/* Premium Apparel */}
                <div>
                  <h3 className="font-bold mb-3 text-brand-500">
                    Premium Apparel
                  </h3>

                  <Link to="/category/korean-shirt" className="block mb-2 hover:text-brand-500">
                    Korean Style Shirts
                  </Link>

                  <Link to="/category/minimal-polo" className="block mb-2 hover:text-brand-500">
                    Minimal Premium Polo
                  </Link>

                  <Link to="/category/hoodie" className="block mb-2 hover:text-brand-500">
                    Hoodie
                  </Link>

                  <Link to="/category/oversized-hoodie" className="block mb-2 hover:text-brand-500">
                    Oversized Hoodie
                  </Link>

                  <Link to="/category/jersey" className="block hover:text-brand-500">
                    Jersey
                  </Link>
                </div>

                {/* Sports Wear */}
                <div>
                  <h3 className="font-bold mb-3 text-brand-500">
                    Sports Wear
                  </h3>

                  <Link to="/category/sports-tshirt" className="block mb-2 hover:text-brand-500">
                    Sports T-Shirts
                  </Link>

                  <Link to="/category/sports-shorts" className="block mb-2 hover:text-brand-500">
                    Sports Shorts
                  </Link>

                  <Link to="/category/track-pants" className="block py-1 hover:text-brand-500 transition-colors">
                    Track Pants
                  </Link>

                  <Link to="/category/shorts" className="block py-1 hover:text-brand-500 transition-colors">
                    Shorts
                  </Link>

                  <Link to="/category/pant"   className="block py-1 hover:text-brand-500 transition-colors">
                    Pant
                  </Link>
                </div>

                {/* Gifts & Printing */}
                <div>
                  <h3 className="font-bold mb-3 text-brand-500">
                    Gifts & Printing
                  </h3>

                  <Link to="/category/magic-mug" className="block mb-2 hover:text-brand-500">
                    Magic Mug Print
                  </Link>

                  <Link to="/category/photo-frame" className="block mb-2 hover:text-brand-500">
                    Photo Frames
                  </Link>

                  <Link to="/category/metal-frame" className="block mb-2 hover:text-brand-500">
                    Metal Frames
                  </Link>

                  <Link to="/category/mouse-pad" className="block mb-2 hover:text-brand-500">
                    Mouse Pads
                  </Link>

                  <Link to="/category/personal-gifts" className="block hover:text-brand-500">
                    Personal Gifts
                  </Link>

                  <Link to="/category/White Mug" className="block py-1 hover:text-brand-500 transition-colors">
                    White Mug
                  </Link>

                  <Link to="/category/Sublimation-products" className="block py-1 hover:text-brand-500 transition-colors">
                    Sublimation Products
                  </Link>
                </div>

                {/* Accessories */}
                <div>
                  <h3 className="font-bold mb-3 text-brand-500">
                    Accessories
                  </h3>

                  <Link to="/category/water-bottle" className="block mb-2 hover:text-brand-500">
                    Water Bottles
                  </Link>

                  <Link to="/category/tumbler" className="block mb-2 hover:text-brand-500">
                    Skinny Tumblers
                  </Link>

                  <Link to="/category/glassware" className="block mb-2 hover:text-brand-500">
                    Glass Ware
                  </Link>

                  <Link to="/category/hats" className="block mb-2 hover:text-brand-500">
                    Hats & Caps
                  </Link>

                  <Link to="/category/cards" className="block py-1 hover:text-brand-500 transition-colors">
                    Wedding & Greeting Cards
                  </Link>

                  <Link to="/category/pillows" className="block py-1 hover:text-brand-500 transition-colors">
                    Pillows
                  </Link>
                </div>

              </div>
              )}
            </div>
            <Link to="/tracking" className={clsx(
              "transition-colors duration-200 hover:text-brand-500",
              location.pathname === '/tracking' ? "text-brand-500 font-semibold" : "text-app/80"
            )}>
              Track Order
            </Link>
          </nav>

          {/* Search Box - Desktop */}
          <form onSubmit={handleSearchSubmit} className="hidden lg:flex items-center relative max-w-xs w-full">
            <input
              type="text"
              placeholder="Search premium apparel..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-surface border border-app rounded-full py-1.5 pl-4 pr-10 text-xs text-app focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 transition-all duration-300 placeholder:text-muted"
            />
            <button type="submit" className="absolute right-3 text-muted hover:text-app transition-colors duration-200">
              <Search size={14} />
            </button>
          </form>

          {/* Right Action Icons */}
          <div className="flex items-center gap-2 sm:gap-4">
            
            {/* Theme Toggle */}
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-surface text-app transition-colors duration-200"
              aria-label="Toggle Theme"
            >
              {isDark ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {/* Wishlist */}
            <Link 
              to="/wishlist" 
              className="p-2 rounded-full hover:bg-surface text-app transition-colors duration-200 relative"
              aria-label="Wishlist"
            >
              <Heart size={18} />
              {wishlistCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[9px] font-bold h-4 w-4 rounded-full flex items-center justify-center animate-pulse">
                  {wishlistCount}
                </span>
              )}
            </Link>

            {/* Cart */}
            <Link 
              to="/cart" 
              className="p-2 rounded-full hover:bg-surface text-app transition-colors duration-200 relative"
              aria-label="Cart"
            >
              <ShoppingCart size={18} />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-brand-500 text-white text-[9px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>

            {/* Account / Login */}
            {token && customer ? (
              <div className="relative group/profile">
                <Link to="/profile" className="flex items-center gap-2 p-1.5 rounded-full hover:bg-surface text-app transition-colors duration-200">
                  <div className="h-7 w-7 rounded-full bg-brand-500 flex items-center justify-center text-white font-bold text-xs">
                    {customer.first_name[0].toUpperCase()}
                  </div>
                  <span className="hidden sm:inline text-xs font-semibold max-w-[80px] truncate">{customer.first_name}</span>
                </Link>
                {/* Profile Hover Dropdown */}
                <div className="absolute right-0 mt-1.5 w-48 bg-app border border-app rounded-xl shadow-lg py-2 hidden group-hover/profile:block animate-fade-in z-50">
                  <Link to="/profile" className="flex items-center gap-2 px-4 py-2 text-xs text-app hover:bg-surface">
                    <User size={13} />
                    My Account
                  </Link>
                  <Link to="/profile/orders" className="flex items-center gap-2 px-4 py-2 text-xs text-app hover:bg-surface">
                    <ClipboardList size={13} />
                    My Orders
                  </Link>
                  <hr className="border-app my-1" />
                  <button onClick={handleLogout} className="flex w-full items-center gap-2 px-4 py-2 text-xs text-red-500 hover:bg-surface text-left">
                    <LogOut size={13} />
                    Logout
                  </button>
                </div>
              </div>
            ) : (
              <Link to="/auth/login" className="flex items-center gap-1.5 btn-primary py-1.5 px-4 rounded-full text-xs">
                <User size={13} />
                <span>Sign In</span>
              </Link>
            )}

            {/* Mobile Menu Toggle */}
            <button 
              onClick={() => setMobileMenuOpen(true)}
              className="p-2 rounded-full hover:bg-surface text-app transition-colors duration-200"
              aria-label="Open Navigation Menu"
            >
              <Menu size={18} />
            </button>

          </div>

        </div>
      </header>
    </>
  );
}



